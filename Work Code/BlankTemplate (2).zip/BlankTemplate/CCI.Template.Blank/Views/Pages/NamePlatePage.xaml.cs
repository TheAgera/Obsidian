﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.DirectoryServices.AccountManagement;
using CCI.Template.Blank.Models;
using CCI.Template.Blank;
using System.DirectoryServices;
using System.Runtime.CompilerServices;
using CsvHelper;
using CsvHelper.Configuration;
using System.IO;
using System.Globalization;
using Microsoft.Win32;
using System.Windows.Interop;
using Microsoft.VisualBasic;
using System.Data;
using System.Windows.Controls.Primitives;

namespace CCI.Template.Blank.Views.Pages
{
    /// <summary>
    /// Interaction logic for NamePlatePage.xaml
    /// </summary>
    public partial class NamePlatePage
    {
        public NamePlatePage()
        {
            InitializeComponent();
           // dg_Names.ItemsSource = userNames.ADUserCollection;
          DG_Names.ItemsSource = userNames.inputUsers;
           //
           // LV_Names.ItemTemplate = 
            
        }

        private void initializeGUI()
        {
            
        }
        private T GetVisualChild<T>(DependencyObject parent) where T : Visual
        {
            T child = default(T);
            int numVisuals = VisualTreeHelper.GetChildrenCount(parent);
            for (int i = 0; i < numVisuals; i++)
            {
                Visual v = (Visual)VisualTreeHelper.GetChild(parent, i);
                child = v as T;
                if (child == null)
                {
                    child = GetVisualChild<T>(v);
                }
                if (child != null)
                {
                    break;
                }
            }
            return child;
        }
        private ComboBox GetComboBox(int rowIndex, int columnIndex)
        {
            DataGridRow row = (DataGridRow)DG_Names.ItemContainerGenerator.ContainerFromIndex(rowIndex);
            if (row == null)
                return null;

            DataGridCellsPresenter presenter = GetVisualChild<DataGridCellsPresenter>(row);
            DataGridCell cell = (DataGridCell)presenter.ItemContainerGenerator.ContainerFromIndex(columnIndex);

            if (cell.Content is ContentPresenter contentPresenter)
            {
                DataTemplate dataTemplate = contentPresenter.ContentTemplate;
                ComboBox comboBox = (ComboBox)dataTemplate.FindName("CB_Size_Selector", contentPresenter);
                return comboBox;
            }

            return null;
        }
        private string GetSelectedItemContent(ComboBox comboBox)
        {
            if (comboBox.SelectedItem is ComboBoxItem selectedItem)
            {
                return selectedItem.Content.ToString();
            }
            else if (comboBox.SelectedItem != null)
            {
                return comboBox.SelectedItem.ToString();
            }

            return "No item selected";
        }
        private void b_csvImport(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Multiselect = false;
            openFileDialog.Filter = "*.csv|*.csv";
            bool? result = openFileDialog.ShowDialog();
            if (result == true)
            {
               

                using (var reader = new StreamReader(openFileDialog.FileName))
                using (var csv = new CsvReader(reader, CultureInfo.InvariantCulture))
                {

                    var records = csv.GetRecords<CSVUsers>();
                    foreach (var record in records)
                    {
                       userNames.CSVUser.Add(record);
                    }
                }
            }            
        }

        private void LV_Name_LeftUp(object sender, MouseButtonEventArgs e)
        {

        }

        private void LV_Name_RightUp(object sender, MouseButtonEventArgs e)
        {

        }

        private void b_generateNames_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btn_ADImport(object sender, RoutedEventArgs e)
        {
            // Define the context for querying Active Directory, PrincipalContext encapsulates domain that operations are performed against,
            using (var context = new PrincipalContext(ContextType.Domain, "CommerceControls.com" , "OU=Users,OU=CCI,OU=Companies,DC=CommerceControls,DC=com"))
            {
                // Create a user principal object for searching
                using (var searcher = new PrincipalSearcher(new UserPrincipal(context) { Enabled = true}))
                {
                    foreach (var result in searcher.FindAll())
                    {
                       
                        DirectoryEntry de = result.GetUnderlyingObject() as DirectoryEntry;
          
                        InputUser user = new InputUser();
                        user.First = (string?)de.Properties["givenName"].Value;
                        user.Last = (string?)de.Properties["sn"].Value;
                        user.Department = (string?)de.Properties["department"].Value;
                        user.Division = (string?)de.Properties["division"].Value;
                        user.Title = (string?)de.Properties["title"].Value;
                        //userNames.ADUserCollection.Add(de);
                        userNames.inputUsers.Add(user);
                    }
                }
            }
            Console.ReadLine();
        }

        private void SearchTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            Console.WriteLine(e.Changes.ToString());
            MessageBox.Show(e.Changes.ToString());
        }

        private void btn_Add_OutputUser(object sender, RoutedEventArgs e)
        {
            // To access the combobox and button, I need to access the position in the row, and the column the combobox/button are in. Parent and child objects
            ComboBox comboBox = GetComboBox(0, 0);
            if (comboBox != null)
            {
                var selectedItem = comboBox.SelectedItem;
                string selectedItemContent = GetSelectedItemContent(comboBox);
                MessageBox.Show($"Selected Item: {selectedItemContent}", "ComboBox Selected Item", MessageBoxButton.OK, MessageBoxImage.Information);

            }

        }





















        //private void typeUser()
        //{
        //     Define the context for querying Active Directory, PrincipalContext encapsulates domain that operations are performed against,
        //    using (var context = new PrincipalContext(ContextType.Domain, "CommerceControls.com", "OU=Users,OU=CCI,OU=Companies,DC=CommerceControls,DC=com"))
        //    {
        //         Create a user principal object for searching
        //        UserPrincipal userPrincipal = new UserPrincipal(context);
        //        {
        //             = "ksuess",
        //            foreach (var result in searcher.FindAll())
        //            {

        //                DirectoryEntry de = result.GetUnderlyingObject() as DirectoryEntry;
        //            }
        //        }
        //    }
        //}
    }
}   
